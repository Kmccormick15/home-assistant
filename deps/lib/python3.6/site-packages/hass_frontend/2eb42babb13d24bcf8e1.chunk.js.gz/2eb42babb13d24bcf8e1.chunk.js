(window.webpackJsonp=window.webpackJsonp||[]).push([[32],{643:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);var _polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(0),_polymer_polymer_polymer_element_js__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_layouts_partial_cards_js__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(183);class HaPanelKiosk extends _polymer_polymer_polymer_element_js__WEBPACK_IMPORTED_MODULE_1__.a{static get template(){return _polymer_polymer_lib_utils_html_tag_js__WEBPACK_IMPORTED_MODULE_0__.a`
    <partial-cards
      id='kiosk-states'
      hass='[[hass]]'
      show-menu
      route='[[route]]'
      panel-visible
    ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}}customElements.define("ha-panel-kiosk",HaPanelKiosk)}}]);
//# sourceMappingURL=2eb42babb13d24bcf8e1.chunk.js.map